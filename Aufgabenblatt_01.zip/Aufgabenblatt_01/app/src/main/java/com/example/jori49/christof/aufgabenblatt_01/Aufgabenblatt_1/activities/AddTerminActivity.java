package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.jori49.christof.aufgabenblatt_01.R;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.AppDatabase;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.Appointment;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.AppointmentDAO;

import java.util.Calendar;
import java.util.Date;

public class AddTerminActivity extends AppCompatActivity implements View.OnClickListener{

    private Button saveit;
    private EditText s, e, d;
    private Calendar c;
    private DatePickerDialog picker;
    private Date start, end;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_termin);

        s = findViewById(R.id.start_ET);
        e = findViewById(R.id.end_ET);
        d = findViewById(R.id.descr_ET);

        s.setOnClickListener(this);
        e.setOnClickListener(this);

        saveit = findViewById(R.id.saveIt);
        saveit.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.start_ET:{

                c = Calendar.getInstance();
                int day = c.get(Calendar.DAY_OF_MONTH);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);

                picker = new DatePickerDialog(this, (datePicker, i, i1, i2) -> {
                    s.setText(i +"/" + i1 +"/" + i2);
                    start = new Date(i, i1, i2);

                }, day, month, year);

                picker.show();
                break;
            }
            case R.id.end_ET: {
                c = Calendar.getInstance();
                int day = c.get(Calendar.DAY_OF_MONTH);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);

                picker = new DatePickerDialog(this, (datePicker, i, i1, i2) -> {
                    e.setText(i +"/" + i1 +"/" + i2);
                    end = new Date(i, i1, i2);
                }, day, month, year);

                picker.show();
                break;
            }
            case R.id.saveIt: {
                AppDatabase db = AppDatabase.getInstance(this);
                AppointmentDAO dao = db.appointmentDAO();

                dao.insertAll(new Appointment(start, end, d.getText().toString()));

                startActivity(new Intent(this, TerminPlanerActivity.class));

            }
        }
    }
}
