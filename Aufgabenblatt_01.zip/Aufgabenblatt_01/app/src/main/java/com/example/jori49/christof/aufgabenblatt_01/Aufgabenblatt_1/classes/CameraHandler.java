package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Size;

import com.example.jori49.christof.aufgabenblatt_01.R;

public class CameraHandler {


    public boolean checkCamera(Activity c, int permissionCode) {
        if (c.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            String[] permission = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
            c.requestPermissions(permission, permissionCode);
        } else return true;

        return false;
    }

    public Uri openCamera(Activity c, int captureCode){
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "Neu");
        Uri image_uri = c.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

        // Camera intent
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);
        c.startActivityForResult(cameraIntent, captureCode);

        return image_uri;
    }


}