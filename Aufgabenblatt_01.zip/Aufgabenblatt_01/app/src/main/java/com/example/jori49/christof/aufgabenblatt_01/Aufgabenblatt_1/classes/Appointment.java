package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes;

import java.io.Serializable;
import java.util.Date;
import java.util.Random;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Appointment implements Serializable {
    @PrimaryKey
    public long id;

    @ColumnInfo(name = "start")
    public Date start;

    @ColumnInfo(name = "end")
    public Date end;

    @ColumnInfo(name = "description")
    public String description;

    public Appointment(Date start, Date end, String description) {
        this.id = new Random().nextInt(1000000);
        this.start = start;
        this.end = end;
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getStart() {
        return start;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    public Date getEnd() {
        return end;
    }

    public void setEnd(Date end) {
        this.end = end;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
