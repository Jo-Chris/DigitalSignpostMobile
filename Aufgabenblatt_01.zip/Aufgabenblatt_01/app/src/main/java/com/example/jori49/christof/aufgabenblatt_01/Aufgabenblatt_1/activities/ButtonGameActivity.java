package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jori49.christof.aufgabenblatt_01.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ButtonGameActivity extends AppCompatActivity implements View.OnClickListener {

    private List<Button> buttonList;
    private TextView leadingView;
    private LinearLayout llayer;
    private static final int COUNTER = 20; //define buttoncontainersize
    private List<Integer> used = new ArrayList<>();
    private static int buttonCounter = 0;
    private Random r = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button_game);

        //init UI
        initUI();

        //leading textView
        createLeadingTextView();

        //create Buttons and add it programmatically
        createAndAddButtons();
    }


    private void initUI(){
        llayer = findViewById(R.id.linLayer);
    }

    private void createAndAddButtons(){
        //button container
        buttonList = new ArrayList<>();

        for (int i = 0; i < COUNTER; i++){
            buttonList.add(new Button(this));
            buttonList.get(i).setOnClickListener(this);
            buttonList.get(i).setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            buttonList.get(i).setText(this.getResources().getString(R.string.button_id_iter, String.valueOf(i)));

            //add view
            llayer.addView(buttonList.get(i));
        }
    }

    private void createLeadingTextView(){
        //ref view
        leadingView = new TextView(this);
        //add view
        llayer.addView(leadingView);
        //set text
        setRandText();

    }


    @Override
    public void onClick(View view) {
        Toast.makeText(this, ((Button)view).getText().toString(), Toast.LENGTH_LONG).show();

        comparePress(view);
    }

    private void setRandText(){
        int randVal = r.nextInt(COUNTER);

        if (!used.contains(randVal)) {
            leadingView.setText(this.getResources().getString(R.string.button_id_iter, String.valueOf(randVal)));
            used.add(randVal);
            buttonCounter++;
        }else{
            setRandText();
        }
    }

    private void comparePress(View v){
        Button b = ((Button)v);

        if (b.getText().toString().equals(leadingView.getText().toString())){
            // set background color
            b.setBackgroundColor(Color.GREEN);
            //increase clicked buttons
            if (checkIfWon()){
                setResult(Activity.RESULT_OK, new Intent().putExtra("status", true));
                finish();
            }
        }
    }

    private boolean checkIfWon(){
        if (buttonCounter == 1) { // < Counter
            System.out.println(("Counter is =" + buttonCounter));
            // start again
            setRandText();

            return false;

        }else{
            leadingView.setText("+++ Gewonnen +++");
            leadingView.setBackgroundColor(Color.GREEN);

            return true;
        }
    }
}
