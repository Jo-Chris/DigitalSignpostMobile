package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@Database(entities = {Appointment.class}, version=1, exportSchema = false)
@TypeConverters(DateConverter.class)
public abstract class AppDatabase extends RoomDatabase {

    //use Singleton
    private static AppDatabase INSTANCE = null;

    public abstract AppointmentDAO appointmentDAO();

    public static AppDatabase getInstance(Context context) {
        if(INSTANCE == null) {
            return Room.databaseBuilder(context, AppDatabase.class, "appDB")
                    // only in here :>
                    .allowMainThreadQueries()
                    .build();
        } else {
            return INSTANCE;
        }
    }

    public static void destrDB() {
        INSTANCE = null;
    }
}
