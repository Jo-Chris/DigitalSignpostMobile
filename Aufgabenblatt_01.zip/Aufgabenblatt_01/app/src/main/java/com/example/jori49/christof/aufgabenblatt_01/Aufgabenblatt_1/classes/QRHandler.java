package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes;

import android.app.Activity;

public class QRHandler   {

    public static void handleQR(Activity activity, String code){

        DeviceHandler handler = new DeviceHandler(activity);

        switch (code){
            case "home":
                handler.setWIFI(true);
                handler.disableWIFI();
                handler.setNormalRingmode();
                System.out.println("Home got activated");

            case "away":
                handler.setWIFI(false);
                handler.enableBluetooth();
                handler.setVibrateRingmode();
                System.out.println("Away got activated");

            case "office":
                handler.setWIFI(true);
                handler.disableWIFI();
                handler.setVibrateRingmode();
                System.out.println("Office got activated");

        }
    }
}
