package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.activities;

import android.content.Intent;
import android.os.Bundle;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.adapter.RecyclerViewAdapter;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.AppDatabase;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.Appointment;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.AppointmentDAO;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.jori49.christof.aufgabenblatt_01.R;
import java.util.List;

public class TerminPlanerActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private AppDatabase db;
    AppointmentDAO dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_termin_planer);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        //get access
        db = AppDatabase.getInstance(this);

        dao = db.appointmentDAO();

        System.out.println("YEEEEEEEEEEEES =" + db);

        //init Recyclerview
        initRecycler();

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> {
            startActivityForResult(new Intent(this, AddTerminActivity.class), 777);
        });
    }

    private void initRecycler(){

        recyclerView = findViewById(R.id.recycler);
        // improves performance, changes do not change the size of layout
        recyclerView.setHasFixedSize(true);
        // define LinearLayout
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        // specify an adapter (see also next example)

        List<Appointment> appList = dao.getAll();

        System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAA = " + appList);

        mAdapter = new RecyclerViewAdapter(dao.getAll());
        recyclerView.setAdapter(mAdapter);

    }
}
