package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import me.dm7.barcodescanner.zxing.ZXingScannerView;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Camera;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.CameraHandler;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.DeviceHandler;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.QRHandler;
import com.example.jori49.christof.aufgabenblatt_01.R;
import com.google.zxing.Result;

public class NewActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler{

    private final int PERMISSION_CODE = 100;
    private static final String TAG = "pf";
    private ZXingScannerView mScannerView;
    private QRHandler qrHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mScannerView = new ZXingScannerView(this);   // Programmatically initialize the scanner view
        setContentView(mScannerView);                // Set the scanner view as the content view

        init();
    }

    private void init(){
        qrHandler = new QRHandler();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mScannerView.setResultHandler(this); // Register ourselves as a handler for scan results.
        mScannerView.startCamera();          // Start camera on resume
    }

    @Override
    protected void onPause() {
        super.onPause();
        super.onPause();
        mScannerView.stopCamera();
    }

    @Override
    public void handleResult(Result rawResult) {
        // Do something with the result here
        Log.v(TAG, rawResult.getText()); // Prints scan results
        Log.v(TAG, rawResult.getBarcodeFormat().toString()); // Prints the scan format (qrcode, pdf417 etc.)


        QRHandler.handleQR(this, rawResult.getText());

        // If you would like to resume scanning, call this method below:
        mScannerView.resumeCameraPreview(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mScannerView.startCamera();
            } else {
                Toast.makeText(this, "Permission denied!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
