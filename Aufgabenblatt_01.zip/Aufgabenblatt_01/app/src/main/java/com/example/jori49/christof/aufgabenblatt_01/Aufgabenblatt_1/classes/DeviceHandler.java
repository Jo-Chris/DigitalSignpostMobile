package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.media.AudioManager;
import android.net.wifi.WifiManager;

public class DeviceHandler {

    private WifiManager wifiManager;
    private BluetoothAdapter bluetoothAdapter;
    private AudioManager am;

    public DeviceHandler(Activity c){
        wifiManager = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        am = (AudioManager) c.getBaseContext().getSystemService(Context.AUDIO_SERVICE);
    }

    public void switchWIFI(){
        wifiManager.setWifiEnabled(!wifiManager.isWifiEnabled());
    }

    public void setWIFI(boolean bool){
        wifiManager.setWifiEnabled(bool);
    }

    public void switchBluetooth(){
        if (bluetoothAdapter.isEnabled()) {
            bluetoothAdapter.disable();
        } else {
            bluetoothAdapter.enable();
        }
    }

    public void disableBluetooth(){
        bluetoothAdapter.disable();
    }

    public void enableBluetooth(){
        bluetoothAdapter.enable();
    }

    public void enableWIFI(){
        bluetoothAdapter.enable();
    }

    public void disableWIFI(){
        bluetoothAdapter.disable();
    }

    public void setSilentRingmode(){
        am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
    }
    public void setNormalRingmode() {
        am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
    }
    public void setVibrateRingmode(){
        am.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
    }

}
