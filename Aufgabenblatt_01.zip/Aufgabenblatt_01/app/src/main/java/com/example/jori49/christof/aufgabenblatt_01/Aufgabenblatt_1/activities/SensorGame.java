package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.jori49.christof.aufgabenblatt_01.R;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class SensorGame extends AppCompatActivity implements SensorEventListener {

    private TextView current, next;
    private ImageView image;
    private List<Integer> directions = new ArrayList<>();
    private Vibrator v;
    private List<Sensor> deviceSensors;
    private SensorManager sensorManager;
    private int curr_degrees = 0;
    private int degrees_to_match = 0;

    private final float[] accelerometerReading = new float[3];
    private final float[] magnetometerReading = new float[3];
    private final float[] rotationMatrix = new float[9];
    private final float[] orientationAngles = new float[3];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_game);
        initUI();

        initSensor();
        createList(5);

        v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

    }

    @Override
    protected void onResume() {
        super.onResume();

        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer,
                    SensorManager.SENSOR_DELAY_NORMAL, SensorManager.SENSOR_DELAY_UI);
        }
        Sensor magneticField = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        if (magneticField != null) {
            sensorManager.registerListener(this, magneticField,
                    SensorManager.SENSOR_DELAY_NORMAL, SensorManager.SENSOR_DELAY_UI);
        }

    }

    @Override
    protected void onPause() {
        super.onPause();

        sensorManager.unregisterListener(this);

    }

    private void initUI(){
        current = findViewById(R.id.current);
        next = findViewById(R.id.next);
        image = findViewById(R.id.imageView);
    }

    private void createList(int length){
        for (int i = 0; i < length; i++){

            int val = (int) ((Math.random() * 36)) * 10;

            if (val == 360) {
                directions.add(val);
            } else {
                directions.add(val);
            }

            System.out.println(directions.get(i));
        }

        degrees_to_match = directions.get(0);
        next.setText(String.valueOf(degrees_to_match));
    }

    private void initSensor(){
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        deviceSensors = sensorManager.getSensorList(Sensor.TYPE_ALL);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            System.arraycopy(sensorEvent.values, 0, accelerometerReading, 0, accelerometerReading.length);
        } else if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            System.arraycopy(sensorEvent.values, 0, magnetometerReading, 0, magnetometerReading.length);
        }

        SensorManager.getRotationMatrix(rotationMatrix, null, accelerometerReading, magnetometerReading);
        SensorManager.getOrientation(rotationMatrix, orientationAngles);


        // rotate the image
        int degrees = (int)Math.round((Math.toDegrees(orientationAngles[0]) + 360 ) % 360);

        current.setText(String.valueOf(degrees));

        rotateAndShow(degrees);
    }

    private void rotateAndShow(int degrees){
        RotateAnimation rotateAnimation = new RotateAnimation(curr_degrees, -degrees, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotateAnimation.setDuration(250);
        rotateAnimation.setFillAfter(true);

        image.startAnimation(rotateAnimation);


        curr_degrees = -degrees;

        // degrees betwen [-5  -  target  -  +5]
        if (degrees >= (degrees_to_match - 5) && degrees <= (degrees_to_match + 5)) {
            checkIfWon();
        }
    }

    public void vibrate(){
        // O = 26
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            //deprecated in API 26
            v.vibrate(500);
        }
    }

    private void checkIfWon(){
        if (directions.size() > 0){
            // set text#
            degrees_to_match = directions.get(0);
            next.setText(String.valueOf(degrees_to_match));
            // remove
            directions.remove(0);
            //Toast
            Toast.makeText(this, "Jep, correct", Toast.LENGTH_SHORT).show();
            //vibrate
            vibrate();

        }else{
            Toast.makeText(this, "Yep, you've won", Toast.LENGTH_LONG).show();
            next.setText(getResources().getString(R.string.won));
            current.setText(getResources().getString(R.string.won));
        }
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
        // not used
    }
}
