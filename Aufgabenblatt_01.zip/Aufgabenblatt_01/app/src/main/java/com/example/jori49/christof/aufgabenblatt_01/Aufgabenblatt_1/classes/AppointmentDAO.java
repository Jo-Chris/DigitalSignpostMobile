package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface AppointmentDAO {

    @Query("SELECT * FROM appointment")
    List<Appointment> getAll();

    @Insert
    void insertAll(Appointment... appoints);

    @Delete
    void delete(Appointment appoint);

}
