package com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.activities;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.jori49.christof.aufgabenblatt_01.R;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.AppDatabase;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.Appointment;
import com.example.jori49.christof.aufgabenblatt_01.Aufgabenblatt_1.classes.AppointmentDAO;

import java.util.Date;
import java.util.HashMap;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private static final String TAG = "main1";
    // UI
    private Random r;
    private Button colorBtn, changeActBtn, openAppointBtn, randomAppointment, settingsBtn, sensorGame;
    private LinearLayout linearLayout;

    //DB
    private AppDatabase db;
    AppointmentDAO dao;

    @Override
    protected void onResume() {
        super.onResume();

        changeActBtn.setVisibility((PreferenceManager.getDefaultSharedPreferences(MainActivity.this).getBoolean("change_act", false)) ? View.VISIBLE : View.GONE);
        colorBtn.setVisibility((PreferenceManager.getDefaultSharedPreferences(MainActivity.this).getBoolean("change_background", false)) ? View.VISIBLE : View.GONE);
        openAppointBtn.setVisibility((PreferenceManager.getDefaultSharedPreferences(MainActivity.this).getBoolean("add_new_appoint", false)) ? View.VISIBLE : View.GONE);
        randomAppointment.setVisibility((PreferenceManager.getDefaultSharedPreferences(MainActivity.this).getBoolean("create_new_app", false)) ? View.VISIBLE : View.GONE);
        sensorGame.setVisibility((PreferenceManager.getDefaultSharedPreferences(MainActivity.this).getBoolean("sensor_game", false)) ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* connect DB */
        connectDB();

        /* initialize UI components & utils */
        initHelpers();
        initUIComponents();

        /* add listeners */
        addListeners();

        dbTest();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 77 && resultCode == RESULT_OK && data != null){
            if(data.getExtras().getBoolean("status")){
                linearLayout.setBackgroundColor(Color.GREEN);
            }
        }
    }

    private void initUIComponents(){
        linearLayout = findViewById(R.id.linLayout);

        // programmatically
        colorBtn = new Button(this);
        colorBtn.setText(getResources().getString(R.string.change_backgroundcolor));

        changeActBtn = new Button(this);
        changeActBtn.setText(getResources().getString(R.string.change_activity));

        openAppointBtn = new Button(this);
        openAppointBtn.setText(getResources().getString(R.string.add_new_appointment));

        randomAppointment = new Button(this);
        randomAppointment.setText(getResources().getString(R.string.zufaelliger_termin));

        settingsBtn = new Button(this);
        settingsBtn.setText(getResources().getString(R.string.settings));

        sensorGame = new Button(this);
        sensorGame.setText(getResources().getString(R.string.sensor_game));
        sensorGame.setBackgroundColor(Color.RED);

        linearLayout.addView(colorBtn);
        linearLayout.addView(changeActBtn);
        linearLayout.addView(openAppointBtn);
        linearLayout.addView(randomAppointment);
        linearLayout.addView(settingsBtn);
        linearLayout.addView(sensorGame);


    }

    private void initHelpers(){
        r = new Random();
    }

    private void addListeners(){
        colorBtn.setOnClickListener(this);
        changeActBtn.setOnClickListener(this);
        openAppointBtn.setOnClickListener(this);
        randomAppointment.setOnClickListener(this);
        settingsBtn.setOnClickListener(this);
        sensorGame.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        if (view.equals(colorBtn)){
            linearLayout.setBackgroundColor(Color.rgb((r.nextInt()*255),(r.nextInt()*255),(r.nextInt()*255)));
        }else if (view.equals(changeActBtn)){
            startActivityForResult(new Intent(this, ButtonGameActivity.class), 77);
        }else if (view.equals(openAppointBtn)){
            startActivity(new Intent(this, TerminPlanerActivity.class));
        }else if(view.equals(randomAppointment)){
            createAppointment();
        }else if(view.equals(settingsBtn)){
            startActivity(new Intent(this, SettingsActivity.class));
        }else if(view.equals(sensorGame)){
            startActivity(new Intent(this, SensorGame.class));
        }
    }

    public void connectDB(){
        // use allowMainThreadQueries() for this purpose :>
        db = AppDatabase.getInstance(this);
        dao = db.appointmentDAO();

        System.out.println("Established DB Connection successfully: ");
    }

    private void dbTest(){
        dao.insertAll(new Appointment(new Date(), new Date(), "Termin beim Sebastion"));

        Log.d(TAG, dao.getAll().toString());
    }

    private void createAppointment(){
        dao.insertAll(new Appointment(new Date(), new Date(), "Zufälliger Termin geadded!"));
        Toast.makeText(this, "Ein neuer Termin wurde hinzugefügt", Toast.LENGTH_LONG).show();
    }


}
